@echo off
setlocal
title lanfile uninstall
taskkill /f /im lanfile.exe >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\lanfile.vbs" >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\lanfile.lnk" >nul 2>&1
del "%LOCALAPPDATA%\lanfile\lanfile-open.vbs" >nul 2>&1
netsh advfirewall firewall delete rule name="lanfile" >nul 2>&1
echo.
echo   lanfile stopped.
echo   Removed: autostart entry, start menu shortcut, firewall rule.
echo   Program files kept in %LOCALAPPDATA%\lanfile
echo   Received files kept in %USERPROFILE%\Desktop
echo.
pause
