@echo off
setlocal
title lanfile setup
set "DEST=%LOCALAPPDATA%\lanfile"
set "RECDIR=%USERPROFILE%\Desktop"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

echo.
echo   lanfile setup
echo   install to : %DEST%
echo   receive to : %RECDIR%
echo.

if not exist "%~dp0lanfile.exe" (
  echo   [ERROR] lanfile.exe not found next to this script.
  echo           Extract the whole zip to a folder first, then run install.bat.
  echo.
  pause
  exit /b 1
)

if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0lanfile.exe" "%DEST%\lanfile.exe" >nul
if errorlevel 1 goto :fail
copy /y "%~dp0lanfile.ico" "%DEST%\lanfile.ico" >nul

rem start at login, window hidden
> "%STARTUP%\lanfile.vbs" echo Set sh = CreateObject("WScript.Shell")
>>"%STARTUP%\lanfile.vbs" echo sh.CurrentDirectory = "%DEST%"
>>"%STARTUP%\lanfile.vbs" echo sh.Run """%DEST%\lanfile.exe"" receive -keepalive -dir ""%RECDIR%""", 0, False

rem double-click entry: wscript keeps the black console from appearing
> "%DEST%\lanfile-open.vbs" echo Set sh = CreateObject("WScript.Shell")
>>"%DEST%\lanfile-open.vbs" echo sh.CurrentDirectory = "%DEST%"
>>"%DEST%\lanfile-open.vbs" echo sh.Run """%DEST%\lanfile.exe"" receive -keepalive -open -dir ""%RECDIR%""", 0, False

rem start menu shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%MENU%\lanfile.lnk'); $s.TargetPath='%WINDIR%\System32\wscript.exe'; $s.Arguments='\"%DEST%\lanfile-open.vbs\"'; $s.IconLocation='%DEST%\lanfile.ico'; $s.Save()" >nul 2>&1

rem inbound rule (needs admin)
netsh advfirewall firewall add rule name="lanfile" dir=in action=allow program="%DEST%\lanfile.exe" enable=yes >nul 2>&1
if errorlevel 1 (
  echo   [WARN] firewall rule not added, other machines may not reach this one.
  echo          Right-click install.bat - Run as administrator.
) else (
  echo   [OK] firewall rule added
)

echo   [OK] autostart registered
echo   [OK] start menu shortcut created
echo.
echo   starting lanfile ...
wscript "%DEST%\lanfile-open.vbs"
echo.
echo   Done. The lanfile window should be open now.
echo   To stop: end lanfile.exe in Task Manager.
echo.
pause
exit /b 0

:fail
echo.
echo   [ERROR] cannot write to %DEST%
echo           Extract the zip to a normal folder and try again,
echo           or right-click install.bat - Run as administrator.
pause
exit /b 1
